/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.promedioarreglo;

/**
 *
 * @author Juan Pablo
 */
public class comprobarsiunarreglo {

    /**
     * @param args the command line arguments
     */
    
    
    ////2. Escriba un programa en Java para comprobar si un arreglo contiene un valor específico///
    
    public static void main(String[] args) {
      int[] arreglo = {2, 4, 6, 8, 10};
        int valor = 6;
        boolean encontrado = false;

        for(int i = 0; i < arreglo.length; i++) {
            if(arreglo[i] == valor) {
                encontrado = true;
                break;
            }
        }

        if(encontrado) {
            System.out.println("El valor " + valor + " se encuentra en el arreglo.");
        } else {
            System.out.println("El valor " + valor + " no se encuentra en el arreglo.");
        }
    }
}