/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.promedioarreglo;

/**
 *
 * @author Juan Pablo
 */
public class MayoresQuePromedio {

    /**
     * @param args the command line arguments
     */
    ///4. Escriba un programa que reciba un arreglo de números enteros y///
    //devuelva la de números que son mayores que el promedio de todos los números del arreglo.///
  public static void main(String[] args) {
        int[] arreglo = {2, 4, 6, 8, 10};
        double promedio = 0;
        int cantidadMayores = 0;

        for(int i = 0; i < arreglo.length; i++) {
            promedio += arreglo[i];
        }

        promedio /= arreglo.length;

        for(int i = 0; i < arreglo.length; i++) {
            if(arreglo[i] > promedio) {
                cantidadMayores++;
            }
        }

        System.out.println("La cantidad de números mayores que el promedio es: " + cantidadMayores);
    }
}