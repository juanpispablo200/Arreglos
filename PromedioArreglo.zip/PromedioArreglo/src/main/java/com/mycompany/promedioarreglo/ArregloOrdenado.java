/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.promedioarreglo;

/**
 *
 * @author Juan Pablo
 */
public class ArregloOrdenado {

    /**
     * @param args the command line arguments
     */
    
    
    ////5.Escriba un programa que reciba un arreglo de números enteros y devuelva verdadero 
   ///si el arreglo está ordenado en orden ascendente y falso en caso contrario.////
    
    public static void main(String[] args) {
        // TODO code application logic here
        
         int[] arreglo = {2, 4, 6, 8, 10};
        boolean ordenado = true;

        for(int i = 0; i < arreglo.length - 1; i++) {
            if(arreglo[i] > arreglo[i+1]) {
                ordenado = false;
                break;
            }
        }

        if(ordenado) {
            System.out.println("El arreglo está ordenado en orden ascendente.");
        } else {
            System.out.println("El arreglo no está ordenado en orden ascendente.");
        }
        
        
    }
    
}
