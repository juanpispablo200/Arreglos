/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.promedioarreglo;

/**
 *
 * @author Juan Pablo
 */
public class PromedioArreglo {
//// 1.Escriba un programa en Java para calcular el valor promedio de los elementos de un arreglo.///
    public static void main(String[] args) {
      
         int[] arreglo = {2, 4, 6, 8, 10};
        double promedio = 0;

        for(int i = 0; i < arreglo.length; i++) {
            promedio += arreglo[i];
        }

        promedio /= arreglo.length;

        System.out.println("El promedio de los elementos del arreglo es: " + promedio);
    }
}
    

